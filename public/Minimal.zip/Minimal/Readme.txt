Thanks for downloading this template!

Template Name: Minimal
Template URL: https://templatemag.com/minimal-bootstrap-template/
Author: TemplateMag.com
License: https://templatemag.com/license/